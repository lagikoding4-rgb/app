package com.bonsamp.mobile.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.bonsamp.mobile.databinding.ActivityDownloadBinding

class DownloadActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDownloadBinding

    // Data awal dari screenshot (68%)
    private var totalPct = 68f
    private var f1pct = 68f; private var f2pct = 68f
    private var f3pct = 66f; private var f4pct = 67f

    private val f1total = 18.30f; private val f2total = 12.10f
    private val f3total = 9.25f;  private val f4total = 6.45f

    private val speeds = listOf("3.25 MB/s","3.41 MB/s","2.98 MB/s","3.67 MB/s","3.12 MB/s")
    private var speedIdx = 0
    private var handler = Handler(Looper.getMainLooper())
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDownloadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        updateUI()
        startDownload()
    }

    private fun startDownload() {
        running = true
        val runnable = object : Runnable {
            override fun run() {
                if (!running) return
                if (totalPct >= 100f) {
                    binding.tvStatus.text = "Download selesai!"
                    binding.tvSpeed.text = "✅ Selesai"
                    binding.tvPct.text = "100%"
                    binding.progressMain.progress = 100
                    binding.progressRing.progress = 100
                    return
                }
                totalPct = minOf(100f, totalPct + 0.5f)
                f1pct = minOf(100f, f1pct + 0.5f)
                f2pct = minOf(100f, f2pct + 0.4f)
                f3pct = minOf(100f, f3pct + 0.45f)
                f4pct = minOf(100f, f4pct + 0.5f)
                speedIdx = (speedIdx + 1) % speeds.size
                updateUI()
                handler.postDelayed(this, 300)
            }
        }
        handler.postDelayed(runnable, 300)
    }

    private fun updateUI() {
        val pct = totalPct.toInt()
        binding.tvPct.text = "$pct%"
        binding.progressMain.progress = pct
        binding.progressRing.progress = pct
        binding.tvSpeed.text = speeds[speedIdx]

        val done = (18.45f + (totalPct - 68f) * 0.1f).coerceAtMost(27.12f)
        binding.tvSize.text = "${"%.2f".format(done)} MB / 27.12 MB"

        binding.tvStatus.text = when {
            pct < 80 -> "Downloading files..."
            pct < 95 -> "Verifying files..."
            else -> "Finishing up..."
        }

        // Per file
        val f1done = (f1total * f1pct / 100f)
        val f2done = (f2total * f2pct / 100f)
        val f3done = (f3total * f3pct / 100f)
        val f4done = (f4total * f4pct / 100f)

        binding.progress1.progress = f1pct.toInt()
        binding.tv1Pct.text = "${f1pct.toInt()}%"
        binding.tv1Size.text = "${"%.2f".format(f1done)} MB / ${"%.2f".format(f1total)} MB"

        binding.progress2.progress = f2pct.toInt()
        binding.tv2Pct.text = "${f2pct.toInt()}%"
        binding.tv2Size.text = "${"%.2f".format(f2done)} MB / ${"%.2f".format(f2total)} MB"

        binding.progress3.progress = f3pct.toInt()
        binding.tv3Pct.text = "${f3pct.toInt()}%"
        binding.tv3Size.text = "${"%.2f".format(f3done)} MB / ${"%.2f".format(f3total)} MB"

        binding.progress4.progress = f4pct.toInt()
        binding.tv4Pct.text = "${f4pct.toInt()}%"
        binding.tv4Size.text = "${"%.2f".format(f4done)} MB / ${"%.2f".format(f4total)} MB"
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacksAndMessages(null)
    }
}
