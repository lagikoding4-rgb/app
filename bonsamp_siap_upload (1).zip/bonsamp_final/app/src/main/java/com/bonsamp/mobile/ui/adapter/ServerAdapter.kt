package com.bonsamp.mobile.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bonsamp.mobile.R
import com.bonsamp.mobile.model.ServerEntry

class ServerAdapter(private val items: MutableList<ServerEntry>) :
    RecyclerView.Adapter<ServerAdapter.VH>() {

    private var selectedPos = -1

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tv_server_name)
        val tvAddr: TextView = v.findViewById(R.id.tv_server_addr)
        val tvPlayers: TextView = v.findViewById(R.id.tv_server_players)
        val tvPing: TextView = v.findViewById(R.id.tv_server_ping)
        val tvMode: TextView = v.findViewById(R.id.tv_server_mode)
        val pingBar1: View = v.findViewById(R.id.ping_bar1)
        val pingBar2: View = v.findViewById(R.id.ping_bar2)
        val pingBar3: View = v.findViewById(R.id.ping_bar3)
        val pingBar4: View = v.findViewById(R.id.ping_bar4)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_server, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        holder.tvName.text = s.name
        holder.tvAddr.text = "${s.ip}:${s.port}"
        holder.tvPlayers.text = "${s.players} / ${s.maxPlayers}"
        holder.tvMode.text = s.gamemode

        // Ping color & bars
        val pingColor = if (s.ping < 60)
            ContextCompat.getColor(holder.itemView.context, R.color.ping_good)
        else
            ContextCompat.getColor(holder.itemView.context, R.color.ping_mid)

        listOf(holder.pingBar1, holder.pingBar2, holder.pingBar3, holder.pingBar4)
            .forEach { it.setBackgroundColor(pingColor) }

        holder.tvPing.text = "${s.ping}ms"

        // Selected highlight
        holder.itemView.isSelected = selectedPos == position
        holder.itemView.setOnClickListener {
            val prev = selectedPos
            selectedPos = holder.adapterPosition
            if (prev != -1) notifyItemChanged(prev)
            notifyItemChanged(selectedPos)
        }
    }

    override fun getItemCount() = items.size

    fun getSelected(): ServerEntry? =
        if (selectedPos in items.indices) items[selectedPos] else null
}
