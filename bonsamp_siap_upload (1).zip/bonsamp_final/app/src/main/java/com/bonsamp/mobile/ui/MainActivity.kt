package com.bonsamp.mobile.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bonsamp.mobile.R
import com.bonsamp.mobile.databinding.ActivityMainBinding
import com.bonsamp.mobile.ui.fragment.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var activeNavId: Int = R.id.nav_home

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load fragment pertama
        if (savedInstanceState == null) {
            loadFragment(HomeFragment(), R.id.nav_home)
        }

        setupNavigation()
    }

    private fun setupNavigation() {
        binding.navHome.setOnClickListener { loadFragment(HomeFragment(), R.id.nav_home) }
        binding.navPlay.setOnClickListener { loadFragment(PlayFragment(), R.id.nav_play) }
        binding.navServers.setOnClickListener { loadFragment(ServersFragment(), R.id.nav_servers) }
        binding.navNews.setOnClickListener { loadFragment(NewsFragment(), R.id.nav_news) }
        binding.navDownload.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
        binding.navSettings.setOnClickListener { loadFragment(SettingsFragment(), R.id.nav_settings) }
        binding.navExit.setOnClickListener { showExitDialog() }
    }

    private fun loadFragment(fragment: Fragment, navId: Int) {
        activeNavId = navId
        updateNavHighlight(navId)
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun updateNavHighlight(activeId: Int) {
        val navItems = listOf(
            binding.navHome, binding.navPlay, binding.navServers,
            binding.navNews, binding.navDownload, binding.navSettings
        )
        val ids = listOf(
            R.id.nav_home, R.id.nav_play, R.id.nav_servers,
            R.id.nav_news, R.id.nav_download, R.id.nav_settings
        )
        navItems.forEachIndexed { i, view ->
            view.isSelected = ids[i] == activeId
        }
    }

    private fun showExitDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Keluar dari Bonsamp?")
            .setPositiveButton("Ya, Keluar") { _, _ -> finishAffinity() }
            .setNegativeButton("Batal", null)
            .show()
    }
}
