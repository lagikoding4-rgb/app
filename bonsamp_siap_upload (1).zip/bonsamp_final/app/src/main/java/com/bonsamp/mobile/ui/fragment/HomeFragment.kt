package com.bonsamp.mobile.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bonsamp.mobile.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Data statis — sambungkan ke API kamu nanti
        binding.tvPlayersOnline.text = "1,248"
        binding.tvServersOnline.text = "342"
        binding.tvGamemodes.text = "128"
        binding.tvLastUpdate.text = "02 Jun 2024"
        binding.tvClientVersion.text = "1.2.0"
        binding.tvDataVersion.text = "2024.06.02"

        binding.btnDiscord.setOnClickListener {
            // openLink("https://discord.gg/bonsamp")
        }
        binding.btnWebsite.setOnClickListener {
            // openLink("https://bonsamp.id")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
