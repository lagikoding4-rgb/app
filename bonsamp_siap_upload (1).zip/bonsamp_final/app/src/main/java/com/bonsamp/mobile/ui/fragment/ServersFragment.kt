package com.bonsamp.mobile.ui.fragment

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bonsamp.mobile.R
import com.bonsamp.mobile.databinding.FragmentServersBinding
import com.bonsamp.mobile.model.ServerEntry
import com.bonsamp.mobile.ui.adapter.ServerAdapter

class ServersFragment : Fragment() {
    private var _binding: FragmentServersBinding? = null
    private val binding get() = _binding!!

    private val globalServers = mutableListOf(
        ServerEntry("Los Santos Roleplay | Indonesia","ls-rp.com",7777,258,500,32,"LS:RP v3.1"),
        ServerEntry("Balkan School RPG","samp.balkan-school.com",7778,196,400,48,"BS:RP v2.6"),
        ServerEntry("Brasil Play Shox [RPG]","brasilplayshox.com.br",7777,172,350,26,"BPS v2.5"),
        ServerEntry("Next Generation Roleplay","samp.ng-gaming.net",7777,128,300,64,"NG:RP v1.9"),
        ServerEntry("Indonesia City Roleplay","ic-rp.com",7777,104,250,55,"IC:RP v1.4"),
        ServerEntry("Nusantara Roleplay","nrp.id",7777,89,200,38,"NRP v2.0"),
        ServerEntry("Deathmatch Arena","dma.samp.id",7777,64,150,22,"DM v1.0"),
    )
    private val favServers = mutableListOf<ServerEntry>()
    private var isGlobal = true

    private lateinit var globalAdapter: ServerAdapter
    private lateinit var favAdapter: ServerAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentServersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        globalAdapter = ServerAdapter(globalServers)
        favAdapter = ServerAdapter(favServers)

        binding.rvServers.layoutManager = LinearLayoutManager(requireContext())
        binding.rvServers.adapter = globalAdapter

        // Tab switch
        binding.tabGlobal.setOnClickListener { switchTab(true) }
        binding.tabFavorit.setOnClickListener { switchTab(false) }

        // Tambah favorit
        binding.btnAddFav.setOnClickListener { showAddFavDialog() }

        // Join
        binding.btnJoin.setOnClickListener {
            val selected = if (isGlobal) globalAdapter.getSelected()
                          else favAdapter.getSelected()
            if (selected == null) {
                Toast.makeText(requireContext(), "Pilih server dulu!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Joining ${selected.name}...", Toast.LENGTH_SHORT).show()
                // TODO: launch game with IP & port
            }
        }

        updateFavBadge()
    }

    private fun switchTab(global: Boolean) {
        isGlobal = global
        binding.tabGlobal.isSelected = global
        binding.tabFavorit.isSelected = !global
        binding.rvServers.adapter = if (global) globalAdapter else favAdapter
        binding.btnAddFav.visibility = if (global) View.GONE else View.VISIBLE
        updateFavBadge()
    }

    private fun showAddFavDialog() {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val etName = EditText(requireContext()).apply { hint = "Nama Server" }
        val etIp   = EditText(requireContext()).apply { hint = "IP Address" }
        val etPort = EditText(requireContext()).apply { hint = "Port (default 7777)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        layout.addView(etName); layout.addView(etIp); layout.addView(etPort)

        AlertDialog.Builder(requireContext())
            .setTitle("Tambah Server Favorit")
            .setView(layout)
            .setPositiveButton("Simpan") { _, _ ->
                val name = etName.text.toString().trim()
                val ip   = etIp.text.toString().trim()
                val port = etPort.text.toString().trim().toIntOrNull() ?: 7777
                if (name.isNotEmpty() && ip.isNotEmpty()) {
                    favServers.add(ServerEntry(name, ip, port, 0, 0, 0, "Custom"))
                    favAdapter.notifyItemInserted(favServers.size - 1)
                    updateFavBadge()
                } else {
                    Toast.makeText(requireContext(), "Nama dan IP wajib diisi!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateFavBadge() {
        binding.tvFavCount.text = favServers.size.toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
